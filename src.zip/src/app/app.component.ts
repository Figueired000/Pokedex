import { Component } from '@angular/core';
import {Pokemon} from 'src/modules/pokemon'



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'POKEDEX';
  logo="../assets/logo.png";
  imgprofile: string = "..assets/photoPerfil.webp";
  links:string[]=['Home', 'Pokedex','Video Game','Card Games','Eventos'];

  pokemons:Pokemon[]=[
    new Pokemon(1,'Pikachu',['Elétrico'],'Esse é o Pikachu','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRe45eBFxWWfmQ9V8ZUqotv8oIj1gYzbxa0Ow&usqp=CAU'),
    new Pokemon(2,'Bulbasaur',['Grama,Veneno'],'Esse é o Bulbasaur', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRP4IYZv03YrYZ9q0IbvlDZ9BTZd_294C5nqA&usqp=CAU'),
    new Pokemon(1,'Charmander', ['Fogo'],'Esse é o Charmander','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGaYVsuYMQr4BX4vbhxzi2io6lwepmaWeGfQ&usqp=CAU'),
    new Pokemon(2,'Yvisaur',['Grama,Veneno'], 'Esse é o Yvisaur','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4SEe0X-rIqw88ZsQ02LCKON8QF-u2cPnylg&usqp=CAU'),
    new Pokemon(1,'Geodude',['Pedra'],'Esse é o Geodude','https://assets.pokemon.com/assets/cms2/img/pokedex/detail/074.png')
    
  ]
  
  

}
